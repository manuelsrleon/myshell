#define AUTHOR_1_N "Manuel Santamariña Ruiz de León"
#define AUTHOR_1_L "manuel.santamarina"

int authors(char *tokens[], int ntokens);