int create(char *tokens[], int ntokens);
int _stat(char *tokens[], int ntokens);
int list(char *tokens[], int ntokens);
int _delete(char *tokens[], int ntokens);
int deltree(char *tokens[], int ntokens);