void notImplemented();
void printCurrentDirectory();
int has_token(char* tokens[], int ntokens, char* targetToken);