void notImplemented();
void printCurrentDirectory();