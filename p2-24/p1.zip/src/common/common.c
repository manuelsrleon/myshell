void printCurrentDirectory(){
    char cwd[100] = "current working directory";
    getcwd(cwd, 100);
    printf("%s\n",cwd);
}

void notImplemented(char* funcname){
    printf("%s %s\n",funcname,strerror(errno));
}